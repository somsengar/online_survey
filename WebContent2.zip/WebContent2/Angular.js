var app = angular.module('myApp', []);

app.controller('myCtrl', ['$scope','$http',function($scope,$http,$document,$routeParams) {
	
	var myInput = document.getElementById("password");
	var letter = document.getElementById("letter");
	var capital = document.getElementById("capital");
	var number = document.getElementById("number");
	var length = document.getElementById("length");

	myInput.onfocus = function() {
	    document.getElementById("message").style.display = "block";
	}

	myInput.onblur = function() {
	    document.getElementById("message").style.display = "none";
	}

	myInput.onkeyup = function() {
	  var lowerCaseLetters = /[a-z]/g;
	  if(myInput.value.match(lowerCaseLetters)) {  
	    letter.classList.remove("invalid");
	    letter.classList.add("valid");
	  } else {
	    letter.classList.remove("valid");
	    letter.classList.add("invalid");
	  }
	  
	  var upperCaseLetters = /[A-Z]/g;
	  if(myInput.value.match(upperCaseLetters)) {  
	    capital.classList.remove("invalid");
	    capital.classList.add("valid");
	  } else {
	    capital.classList.remove("valid");
	    capital.classList.add("invalid");
	  }

	  var numbers = /[0-9]/g;
	  if(myInput.value.match(numbers)) {  
	    number.classList.remove("invalid");
	    number.classList.add("valid");
	  } else {
	    number.classList.remove("valid");
	    number.classList.add("invalid");
	  }
	  
	  if(myInput.value.length >= 8) {
	    length.classList.remove("invalid");
	    length.classList.add("valid");
	  } else {
	    length.classList.remove("valid");
	    length.classList.add("invalid");
	  }
	}
	
	
	
	
	
	$scope.viewresult=function(){
		alert("calling");
		 $scope.loader=true;
			$http({
			       url:'ViewAnsweres',
				method:"POST",
				data : {}
			
		}).then(function(result){
			$scope.answeres=result.data;
			 $scope.loader=false;
			if($scope.msg==0)
				{
				alert("no data available !")
				}
			else{
				$scope.loader=false;

			}
		},function(result){
			$scope.loader=false;
			alert("Ajax Failed");
		}
		);}
	
	
	
	
	$scope.submitans=function(){
	
		$scope.loader=true;
			$http({
			       url:'AddAnswere',
				method:"POST",
				data : {
					'userid':$scope.userid,
					'questionid':$scope.questionid,
					'username':$scope.username,
					'question':$scope.question,
	                'optiona' :$scope.optiona,
	                'optionb' :$scope.optionb,
	                'optionc' :$scope.optionc,
	                'optiond' :$scope.optiond,
	                'answere':$scope.answere
				}
			
		}).then(function(result){
			$scope.msg=result.data;
			$scope.loader=false;
			if($scope.msg==1)
				{
				
				alert("your answere is submitted successfully!")
				}
			else{
				$scope.loader=false;
				alert("you have already answered!")
			}
		},function(result){
			$scope.loader=false;
			alert("Ajax Failed");
		}
		);}
		
		
		$scope.getquestion=function(){
		$scope.userid=document.getElementById("userid").value;
		$scope.question=document.getElementById("question").value;
		$scope.questionid=document.getElementById("questionid").value;
		$scope.optiona=document.getElementById("optiona").value;
		$scope.optionb=document.getElementById("optionb").value;
		$scope.optionc=document.getElementById("optionc").value;
		$scope.optiond=document.getElementById("optiond").value;
		}
		
	$scope.changestatus=function(){
		
		$scope.loader=true;
		
			$http({
			       url:'ChangeStatus',
				method:"POST",
				data : {
					'questionid':$scope.questionid,
	                'status':$scope.status
	           
	            }
			
		}).then(function(result){
			$scope.msg=result.data;
			if($scope.msg==1)
				{
				$scope.loader=false;
				alert("Status changed Successfully");
				window.location.assign("statuschange.jsp")
				}
			else
				{
				$scope.loader=false;
				alert("This Question is not exist please enter valid question ID..");
				window.location.assign("statuschange.jsp")
				}
			
		},function(result){
			$scope.loader=false;
			alert("Ajax Failed");
		}
		);}
		
	
	
	
	
	$scope.postm=function(){
	
		$scope.loader=true;
		
			$http({
			       url:'AddQuestion',
				method:"POST",
				data : {
					'questionid':$scope.questionid,
					'question':$scope.question,
	                'optiona' :$scope.optiona,
	                'optionb' :$scope.optionb,
	                'optionc' :$scope.optionc,
	                'optiond' :$scope.optiond,
	                'status':$scope.status
	           
	            }
			
		}).then(function(result){
			$scope.msg=result.data;
			if($scope.msg==1)
				{
				$scope.loader=false;
				alert("Question post Successful");
				window.location.assign("addpoll.jsp")
				}
			else
				{
				$scope.loader=false;
				alert("This Question is Already posted..");
				window.location.assign("addpoll.jsp")
				}
			
		},function(result){
			$scope.loader=false;
			alert("Ajax Failed");
		}
		);}
		
	
	
	
	/*login controller*/
	
	$scope.login = function () {
		
			if($scope.userid==null)
				{
				alert("User id should not be empty!");
				}
			else if($scope.password==null){
				alert("password should not be empty!");
			}
			else if($scope.confirmpassword==null)
				{
				alert(" Confirm password should not be empty!");
				}
			else{
				
				if(($scope.password)==($scope.confirmpassword))	
				{
					 $scope.loader=true;
				$http({
				       url:'LoginValidate',
					method:"POST",
					data : {
						     'userid':$scope.userid,
		                     'password' :$scope.password
		        
		                    }
				
			}).then(function(result){
				$scope.msg=result.data;
				if($scope.msg==1)
					{
					 $scope.loader=false;
					
					window.location.assign("welcomeuser.jsp")
					}
				else
					{
					$scope.loader=false;
					alert(result.data);
					window.location.assign("userlogin.jsp")
					}
				
			},function(result){
				$scope.loader=false;
				alert("Ajax failed");
			}
			);}
		
			else{
				$scope.loader=false;
				alert("Both Password should be same!")
			}

			}
					
}


	
	$scope.adminlogin = function () {
		if($scope.adminid==null)
			{
			alert("User id should not be empty!");
			}
		else if($scope.password==null){
			alert("password should not be empty!");
		}
		else if($scope.confirmpassword==null)
			{
			alert(" Confirm password should not be empty!");
			}
		else{
			
			if(($scope.password)==($scope.confirmpassword))	
			{
				$scope.loader=true;
			$http({
			
			       url:'AdminLoginValidate',
				method:"POST",
				data : {
					     'adminId':$scope.adminid,
	                     'password' :$scope.password
	        
	                    }
			
		}).then(function(result){
			$scope.msg=result.data;
			if($scope.msg==1)
				{
				$scope.loader=false;
				window.location.assign("welcomeadmin.jsp")
				}
			else
				{
				$scope.loader=false;
				alert(result.data);
				window.location.assign("adminlogin.jsp")
				}
			
		},function(result){
			$scope.loader=false;
			alert("Ajax failed");
		}
		);}
	
		else{
			$scope.loader=false;
			alert("Both Password should be same!")
		}
	
		}
				
}

	
	$scope.addAdmin = function () {
		
		if(($scope.password)==($scope.confirmpassword))	
			{
			$scope.loader=true;
			$http({
			       url:'AddAdmin',
				method:"POST",
				data : {
					'adminName':$scope.adminname,
					'adminId':$scope.adminid,
	                'password' :$scope.password,
	                'email':$scope.email
	           
	            }
			
		}).then(function(result){
			$scope.msg=result.data;
			if($scope.msg==1)
				{
				$scope.loader=false;
				window.location.assign("adminlogin.jsp")
				}
			else
				{
				$scope.loader=false;
				alert("user id already exist");
				window.location.assign("adminsignup.jsp")
				}
			
		},function(result){
			$scope.loader=false;
			alert("Ajax Failed");
		}
		);}
	
		else{
			$scope.loader=false;
			alert("Both Password should be same!")
		}			
}	
	
	/*Add user controller*/
	
	$scope.add = function () {
		
		if(($scope.password)==($scope.confirmpassword))	
			{
			$scope.loader=true;
			$http({
			       url:'AddUser',
				method:"POST",
				data : {
					'username':$scope.username,
					'userid':$scope.userid,
	                'password' :$scope.password,
	                'email':$scope.email
	           
	            }
			
		}).then(function(result){
			$scope.msg=result.data;
			if($scope.msg==1)
				{
				 $scope.loader=false;

				window.location.assign("userlogin.jsp")
				}
			else
				{
				 $scope.loader=false;

				alert("user id already exist");
				window.location.assign("signup.jsp")
				}
			
		},function(result){
			 $scope.loader=false;
			alert("Ajax Failed");
		}
		);}
	
		else{
			$scope.loader=false;
			alert("Both Password should be same!")
		}			
}	
}]);